frugt = 'ananas'
print (frugt [0:2])