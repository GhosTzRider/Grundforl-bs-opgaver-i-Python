frugt = ("ananas")

for b in frugt: print(b)