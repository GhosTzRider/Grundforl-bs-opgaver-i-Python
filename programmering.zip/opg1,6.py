minBy = 'Odense'
x = len(minBy)
print (x)