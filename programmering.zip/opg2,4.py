from random import random, randint

random
alder = randint (0, 130)
if alder < 18:
    print ('du for ungsomsrabat')
elif alder >= 18 and alder < 65:
    print ('du fÃ¥r ingen rabat')
else:
    print ('du fÃ¥r pensionistrabat')
