'''for i in range(1,1000):
    if i % 3 == 0 and i % 5 == 0:
        print(i)'''


'''for i in range(1,1000):
    if i % 3 == 0 or i % 5 == 0:
        print(i)'''

'''sum = 0
for i in range(1,1000):
    if i % 3 == 0 and i % 5 == 0:
        print(i)
        sum += i
print("summen er: " + str(sum))'''

'''x = int(input("Indtast et tal: "))
y = int(input("Indtast det andet tal: "))

for i in range(x, y):
    if i % 3 == 0 or i % 5 == 0:
        print(i)'''
