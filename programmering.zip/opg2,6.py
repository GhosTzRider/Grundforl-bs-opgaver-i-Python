alder = 17
if alder = 18:
    print('Alder er 18 Ã¥r')
else:
    print('Alder er ikke 18 Ã¥r')

# den kan ikke udskrives fordi at den mangler en "=" i linje 2.