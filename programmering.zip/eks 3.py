frugt = ['an','an','as']
print(frugt[0])
print(frugt[1])
print(frugt[2])
