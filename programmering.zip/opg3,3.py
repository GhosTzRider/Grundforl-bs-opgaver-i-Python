maks = 10

sum = 0
for i in range(10, maks):
    sum = sum + i

    print(sum)

# resultatet er stadig ens.