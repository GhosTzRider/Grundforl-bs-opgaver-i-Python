myName = 'Marcus EllekÃ¦r Rollmann'
print (myName)