MÃ¥nedLg = {'Januar':31,'Februar':28, 'Marts':31, 'April':30, 'Maj':31, 'Juni':31, 'Juli':30, 'August':31, 'September':30, 'Okrober':31, 'November':30, 'December':31}

for x in MÃ¥nedLg:
    print(x,'har', MÃ¥nedLg[x], 'dage')