value = 10
i = 10
i += value
print (i)

#koden regner i plus value og i ud og hvad det giver til sammen som er = 20.