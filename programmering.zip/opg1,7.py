i = 10
i = 1
i += 1
print (i)

#det er 2 fordi at linje 1 bliver overskrevet af linje 2 og derefter er der kun to linjer der kÃ¸re.