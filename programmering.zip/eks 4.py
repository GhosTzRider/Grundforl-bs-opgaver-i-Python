names = ['SÃ¸ren','Neils', 'Anders']
print('element nr. 0 er: ' + names[0])
print('element nr. 1 er: ' + names[1])
print('element nr. 2 er: ' + names[2])