NavneListe = ['Flemming', 'Hans', 'Mikkel', 'Neils', 'Mikolaj', 'Peter']

for x in range(0, len(NavneListe)):
    print('Element nr. ', x, 'er', NavneListe[x])