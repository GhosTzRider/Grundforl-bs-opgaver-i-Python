maks = 10
i = 1
sum = 0
while i < maks:
    sum = sum + i
    i = i + 1
    print(sum)