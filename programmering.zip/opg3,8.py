NavneListe = ['Peter', 'Neils', 'Mikkel', 'Flemming', 'Hans', 'Nikolaj']
sorted_list = sorted(NavneListe)
print(sorted_list)
