Alder = {"SÃ¸ren": 30, "Neils": 31, "Anders": 32}

print ("SÃ¸ren er "+ str (Alder ["SÃ¸ren"]) + " Ã¥r gammel")
print ("Neils er "+ str (Alder["Neils"]) + " Ã¥r gammel")
print ("Anders er " + str (Alder["Anders"]) + " Ã¥r gammel")