maks = 10
i = 1
sum = 0
for i in range(1,maks):
    sum = sum + i
    i = i + 1
    print(sum)