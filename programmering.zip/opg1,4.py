var1 = 17
var2 = 9
var3 = var1 + var2
print (var3)