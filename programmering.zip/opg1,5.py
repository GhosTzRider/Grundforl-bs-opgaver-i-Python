var1 = 'husk '
var2 = 'at'
print (var1 + var2)