MYNDIG = 18
alder = 17

if alder != MYNDIG:
    print('alder er ikke 18')
else:
    print('alder er 18 Ã¥r')

# Koden udskriver "alder er ikke 18" fordi den siger "if alder != MYNDIG"