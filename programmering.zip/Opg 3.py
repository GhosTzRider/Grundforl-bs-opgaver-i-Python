UgeDage = 7

UgeDage = input("VÃ¦lg et tal mellem 1 og 7: ")
UgeDage = int(UgeDage)

if UgeDage == 1:
    print("Mandag")
elif UgeDage == 2:
    print("Tirdag")
elif UgeDage == 3:
    print("Onsdag")
elif UgeDage == 4:
    print("Torsdag")
elif UgeDage == 5:
    print("Fredag")
elif UgeDage == 6:
    print("LÃ¸rdag")
elif UgeDage == 7:
    print("SÃ¸ndag")
else:
    print("Du kan ikke lÃ¦se din spasser")