x = int(input("Please enter a number: "))
sum = sum(range(1, x+1))
print(sum)

