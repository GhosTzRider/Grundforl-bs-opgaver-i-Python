for i in range (0,10):
    print(i)