myVar = 2
print (myVar)