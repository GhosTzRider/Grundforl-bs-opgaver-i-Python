alder = 18
if alder>17:
    print('du har stemmeret')
elif alder<17:
    print('du har ikke stemmeret')
elif alder==17:
    print('du har stemmeret om Ã©t Ã¥r')