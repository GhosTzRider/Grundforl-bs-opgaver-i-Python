NavneListe = ['Peter', 'Neils', 'Mikkel', 'Flemming', 'Hans', 'Nikolaj']
print ('Element nr.0 er: ' + str(NavneListe[0]))
print ( 'Element nr.1 er: ' + str(NavneListe[1]))
print ( 'Element nr.2 er: ' + str(NavneListe[2]))
print ( 'Element nr.3 er: ' + str(NavneListe[3]))
print ( 'Element nr.4 er: ' + str(NavneListe[4]))
print ( 'Element nr.5 er: ' + str(NavneListe[5]))
