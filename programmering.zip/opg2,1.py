alder = 18
if alder>17:
    print('du har stemmeret')