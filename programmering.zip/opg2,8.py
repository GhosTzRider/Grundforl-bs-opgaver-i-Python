from random import random, randint

random 

terningen = randint (1, 6)
if terningen == 1:
    print ('I')
elif terningen == 2:
    print('II')
elif terningen == 3:
    print('III')
elif terningen == 4:
    print('IV')
elif terningen == 5:
    print('V')
elif terningen == 6:
    print('VI')