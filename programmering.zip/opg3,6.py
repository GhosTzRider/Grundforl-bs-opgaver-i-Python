names = ['SÃ¸ren','Neils', 'Anders']
names.remove('Anders')
names.append('Mathias')
names.append('Jens')

print('element nr. 0 er: ' + names[0])
print('element nr. 1 er: ' + names[1])
print('element nr. 2 er: ' + names[2])
print('element nr. 3 er: ' + names[3])


