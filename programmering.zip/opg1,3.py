print('Indtast det fÃ¸rste tal: ')
x = float(input())
print('Indtast det andet tal: ')
y = float(input())
resultat = x + y
print('regnestykket er: ' + str(x) + ' + ' + str(y) + ' = ' + str(resultat))
#a : datatypen er en "float" som gÃ¸re man kan skrive et tal og komma tal.
#b : Hvor Input gÃ¸r at det vi skrive i konsolen bliver en del af koden
#c : det er fordi at alle forskellige koder har brug for en anden slags variable.
#d : datatypen er "string".
#e : du skriver "print(type(x))" og derefter skriver vÃ¦rdien/variabel.